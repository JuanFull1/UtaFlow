
export const supportedRoles = Object.freeze([
  'EXPERTO',
  'COMITE',
  'ADMIN',
])

export function homeForRole(rol) {
  if (rol === 'EXPERTO') return '/app/experto'
  if (rol === 'COMITE') return '/app/comite'
  return '/acceso-denegado'
}
