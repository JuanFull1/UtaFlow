
import { Navigate, Route, Routes } from 'react-router'
import { useAuth } from '../context/AuthContext.js'
import ProtectedRoute from '../components/auth/ProtectedRoute.jsx'
import LoadingScreen from '../components/common/LoadingScreen.jsx'
import Login from '../pages/auth/Login.jsx'
import Authenticated from '../pages/auth/Authenticated.jsx'
import AccessDenied from '../pages/errors/AccessDenied.jsx'
import NotFound from '../pages/errors/NotFound.jsx'
import SolicitudPublica from '../pages/public/SolicitudPublica.jsx'
import SeguimientoPublico from '../pages/public/SeguimientoPublico.jsx'
import { homeForRole } from './accessPolicy.js'

function LoginRoute() {
  const { usuario, status, expiresAt } = useAuth()

  if (usuario && status === 'verifying') {
    return <LoadingScreen />
  }

  if (usuario && expiresAt > 0) {
    return (
      <Navigate
        to={
          status === 'forbidden'
            ? '/acceso-denegado'
            : homeForRole(usuario.rol)
        }
        replace
      />
    )
  }

  return <Login />
}

function AppHome() {
  const { usuario } = useAuth()

  if (usuario.rol === 'EXPERTO') {
    return <Navigate to="/app/experto" replace />
  }

  if (usuario.rol === 'COMITE') {
    return <Navigate to="/app/comite" replace />
  }

  return <AccessDenied />
}

export default function AppRoutes() {
  return (
    <Routes>
      <Route path="/" element={<Navigate to="/login" replace />} />
      <Route path="/login" element={<LoginRoute />} />

      {/* Cliente sin inicio de sesión */}
      <Route path="/solicitud" element={<SolicitudPublica />} />
      <Route path="/seguimiento" element={<SeguimientoPublico />} />

      {/* Rutas autenticadas */}
      <Route path="/app" element={<ProtectedRoute />}>
        <Route index element={<AppHome />} />

        <Route
          element={
            <ProtectedRoute allowedRoles={['EXPERTO']} />
          }
        >
          <Route
            path="experto"
            element={<Authenticated />}
          />
        </Route>

        <Route
          element={
            <ProtectedRoute allowedRoles={['COMITE']} />
          }
        >
          <Route
            path="comite"
            element={<Authenticated />}
          />
        </Route>

        <Route path="*" element={<NotFound />} />
      </Route>

      <Route
        path="/acceso-denegado"
        element={<AccessDenied />}
      />
      <Route path="*" element={<NotFound />} />
    </Routes>
  )
}
